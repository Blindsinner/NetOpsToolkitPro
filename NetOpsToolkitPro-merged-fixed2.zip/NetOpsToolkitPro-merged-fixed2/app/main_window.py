# app/main_window.py
# UPDATED: Removed NetEngWidget. Integrated theme-aware IconManager and global icon updates.
# FIXED: Explicit window flags, minimum size, expanding size policies, and splitter stretch so the window
#        can resize/maximize properly across platforms/window managers.

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QListWidget, QStackedWidget,
    QMessageBox, QToolButton, QSplitter, QListWidgetItem, QSizePolicy
)
from PySide6.QtGui import QIcon, QColor
from PySide6.QtCore import QSettings, QSize, QPoint, Qt

from app.config import AppConfig, qss_dark_theme, qss_light_theme
from app.core.task_manager import TaskManager
from app.core.app_logger import activity_logger
from app.assets.icon_manager import icon_manager

# Domain widgets
from app.widgets.network_ops_widget import NetworkOpsWidget
from app.advanced_features.cybersecurity_widget import CybersecurityWidget
from app.advanced_features.cloud_dashboard import CloudDashboardWidget
from app.advanced_features.security_testing import SecurityTestingWidget
from app.advanced_features.ai_assistant_widget import AIAssistantWidget
from app.widgets.settings_widget import SettingsWidget
from app.advanced_features.blue_team_widget import BlueTeamWidget


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        activity_logger.log("Application Started")
        self.settings = QSettings(AppConfig.ORG_NAME, AppConfig.APP_NAME)
        self.setWindowTitle(f"{AppConfig.APP_NAME} v{AppConfig.APP_VERSION}")

        # --- RESIZE/MAXIMIZE FIXES (start) ---
        # Ensure standard decorations with Min/Max buttons and system menu
        self.setWindowFlags(
            (self.windowFlags() | Qt.Window
             | Qt.WindowMinMaxButtonsHint
             | Qt.WindowSystemMenuHint)
            & ~Qt.CustomizeWindowHint
        )
        # Make sure window is allowed to grow/shrink
        self.setMinimumSize(QSize(800, 500))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        # --- RESIZE/MAXIMIZE FIXES (end) ---

        self.task_manager = TaskManager()

        central_widget = QWidget()
        # Ensure the central widget can expand with the main window
        central_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)

        self.nav_bar = QListWidget()
        self.nav_bar.setObjectName("NavBar")
        self.nav_bar.setFixedWidth(200)
        self.nav_bar.setIconSize(QSize(24, 24))
        # Sidebar should not prevent vertical expansion
        self.nav_bar.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)

        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.addWidget(self.nav_bar)
        self.splitter.addWidget(self.stack)
        self.splitter.setSizes([200, 1080])
        self.splitter.setHandleWidth(1)
        # --- RESIZE/MAXIMIZE FIXES ---
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStretchFactor(0, 0)  # nav stays narrow
        self.splitter.setStretchFactor(1, 1)  # main stack expands
        self.splitter.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        main_layout.addWidget(self.splitter)

        self.domains = [
            {"name": "Network Operations", "widget_class": NetworkOpsWidget, "icon_name": "network"},
            {"name": "Cybersecurity", "widget_class": CybersecurityWidget, "icon_name": "security"},
            {"name": "DevOps & Cloud", "widget_class": CloudDashboardWidget, "icon_name": "cloud"},
            {"name": "Red Team Operations", "widget_class": SecurityTestingWidget, "icon_name": "red_team"},
            {"name": "AI Assistant", "widget_class": AIAssistantWidget, "icon_name": "superpowers"},
            {"name": "Settings", "widget_class": SettingsWidget, "icon_name": "settings"},
            {"name": "🟦 Blue Team", "widget_class": BlueTeamWidget, "icon_name": "security"},
        ]

        self._create_domains()
        self._create_menus()

        self.nav_bar.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav_bar.currentRowChanged.connect(self.log_domain_change)

        self.load_settings()
        self.nav_bar.setCurrentRow(0)

    def log_domain_change(self, index):
        item = self.nav_bar.item(index)
        if not item:
            return
        domain_name = item.text().strip()
        activity_logger.log("Domain Viewed", f"Switched to '{domain_name}' domain.")

    def _create_domains(self):
        for domain in self.domains:
            widget = domain["widget_class"](self.settings, self.task_manager)
            widget.setObjectName("MainContentPanel")
            # Each page should expand with the stack
            widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            self.stack.addWidget(widget)
            item = QListWidgetItem(domain["name"])
            self.nav_bar.addItem(item)

        # Apply initial icons to nav items
        theme = self.settings.value("theme", "dark")
        icon_color = QColor("#1c1c1c") if theme == "light" else QColor("#e0e0e0")
        for i, domain in enumerate(self.domains):
            self.nav_bar.item(i).setIcon(icon_manager.get_icon(domain["icon_name"], icon_color))

    def _create_menus(self):
        menu_bar = self.menuBar()

        # Left corner: sidebar toggle
        self.sidebar_toggle_btn = QToolButton()
        self.sidebar_toggle_btn.setToolTip("Toggle Sidebar")
        self.sidebar_toggle_btn.clicked.connect(self.toggle_sidebar)
        menu_bar.setCornerWidget(self.sidebar_toggle_btn, Qt.Corner.TopLeftCorner)

        # Menus
        file_menu = menu_bar.addMenu("&File")
        file_menu.addAction("E&xit", self.close)
        help_menu = menu_bar.addMenu("&Help")
        help_menu.addAction("&About", self.show_about_dialog)

        # Right corner: theme toggle
        self.theme_button_container = QWidget()
        self.theme_button_container.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        theme_layout = QHBoxLayout(self.theme_button_container)
        theme_layout.setContentsMargins(0, 0, 10, 0)
        self.theme_toggle_button = QToolButton()
        self.theme_toggle_button.setToolTip("Toggle light/dark theme")
        theme_layout.addWidget(self.theme_toggle_button)
        menu_bar.setCornerWidget(self.theme_button_container)

        self.theme_toggle_button.clicked.connect(self.toggle_theme)

    def toggle_sidebar(self):
        sizes = self.splitter.sizes()
        left = sizes[0]
        right = sizes[1] if len(sizes) > 1 else 1
        self.splitter.setSizes([0, right] if left > 0 else [200, right])

    def toggle_theme(self):
        current_theme = self.settings.value("theme", "dark")
        self.set_stylesheet("light" if current_theme == "dark" else "dark")

    def set_stylesheet(self, theme: str):
        if theme == "light":
            self.setStyleSheet(qss_light_theme)
            icon_color = QColor("#1c1c1c")
        else:
            self.setStyleSheet(qss_dark_theme)
            icon_color = QColor("#e0e0e0")

        self.settings.setValue("theme", theme)
        self._update_icons_for_theme(icon_color, theme)

    def _update_icons_for_theme(self, color: QColor, theme: str):
        # Update nav icons
        for i, domain in enumerate(self.domains):
            self.nav_bar.item(i).setIcon(icon_manager.get_icon(domain["icon_name"], color))

        # Update corner widget icons
        self.theme_toggle_button.setIcon(
            icon_manager.get_icon("light_mode" if theme == "dark" else "dark_mode", color)
        )
        self.sidebar_toggle_btn.setIcon(icon_manager.get_icon("menu", color))

        # Let child widgets refresh their icons (if they implement update_icons)
        for i in range(self.stack.count()):
            widget = self.stack.widget(i)
            if hasattr(widget, "update_icons"):
                widget.update_icons(color)

    def show_about_dialog(self):
        QMessageBox.about(
            self,
            f"About {AppConfig.APP_NAME}",
            f"Version: {AppConfig.APP_VERSION}\nThe all-in-one command platform for technical operations.",
        )

    def load_settings(self):
        # Restore size/pos (but keep resizable)
        self.resize(self.settings.value("window_size", QSize(1280, 800)))
        self.move(self.settings.value("window_pos", QPoint(100, 100)))
        if self.settings.contains("windowState"):
            self.restoreState(self.settings.value("windowState"))

        theme = self.settings.value("theme", "dark")
        self.set_stylesheet(theme)

    def closeEvent(self, event):
        activity_logger.log("Application Closed")
        self.settings.setValue("window_size", self.size())
        self.settings.setValue("window_pos", self.pos())
        self.settings.setValue("windowState", self.saveState())
        self.task_manager.cancel_all()
        event.accept()
