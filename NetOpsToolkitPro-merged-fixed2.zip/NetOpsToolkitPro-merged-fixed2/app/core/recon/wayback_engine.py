# app/core/recon/wayback_engine.py
from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional, Tuple
import httpx


class WaybackEngine:
    _AVAIL_URL = "https://archive.org/wayback/available"
    _CDX_URL = "https://web.archive.org/cdx/search/cdx"

    def __init__(self, timeout: float = 15.0):
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    async def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout, http2=True)
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    @staticmethod
    def _run(coro):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(coro)
        else:
            return asyncio.ensure_future(coro)

    async def availability_async(self, url: str) -> Dict[str, Any]:
        client = await self._ensure_client()
        r = await client.get(self._AVAIL_URL, params={"url": url})
        r.raise_for_status()
        return r.json()

    def availability(self, url: str):
        return self._run(self.availability_async(url))

    async def latest_snapshot_url_async(self, domain: str, path: str = "/") -> Optional[str]:
        url = f"https://{domain.rstrip('/')}{path}"
        data = await self.availability_async(url)
        closest = data.get("archived_snapshots", {}).get("closest")
        if closest and closest.get("available"):
            return closest.get("url")
        return None

    def latest_snapshot_url(self, domain: str, path: str = "/"):
        return self._run(self.latest_snapshot_url_async(domain, path))

    async def cdx_search_async(
        self,
        domain: str,
        limit: int = 200,
        status_filter: Optional[str] = "statuscode:200",
        fields: Tuple[str, ...] = ("timestamp", "original", "statuscode", "mimetype"),
        collapse: Optional[str] = "digest",
    ) -> List[Dict[str, str]]:
        client = await self._ensure_client()
        params = {
            "url": f"{domain}/*",
            "output": "json",
            "fl": ",".join(fields),
            "limit": str(limit),
        }
        if status_filter:
            params["filter"] = status_filter
        if collapse:
            params["collapse"] = collapse

        r = await client.get(self._CDX_URL, params=params)
        r.raise_for_status()
        rows = r.json() or []
        results: List[Dict[str, str]] = []
        for row in rows:
            if isinstance(row, list) and len(row) == len(fields):
                results.append({fname: val for fname, val in zip(fields, row)})
        return results

    def cdx_search(
        self,
        domain: str,
        limit: int = 200,
        status_filter: Optional[str] = "statuscode:200",
        fields: Tuple[str, ...] = ("timestamp", "original", "statuscode", "mimetype"),
        collapse: Optional[str] = "digest",
    ):
        return self._run(self.cdx_search_async(domain, limit, status_filter, fields, collapse))

