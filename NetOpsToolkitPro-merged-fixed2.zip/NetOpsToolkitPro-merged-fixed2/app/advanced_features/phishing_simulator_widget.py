# app/advanced_features/phishing_simulator_widget.py
# Realistic phishing composer UI (frontend + backend assembly) with a no-op Send button.
# - Builds RFC822 messages (with attachments) for export
# - Full SMTP settings fields for realism (not used)
# - HTML preview, brand templates, optional tracker pixel
# - "Send" button intentionally does NOTHING (no network, no file writes)

import mimetypes
from email.message import EmailMessage
from pathlib import Path
from typing import List

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLineEdit, QTextEdit,
    QPushButton, QComboBox, QFileDialog, QMessageBox, QLabel, QCheckBox, QGroupBox, QSpinBox
)

from app.widgets.base_widget import BaseToolWidget


class PhishingSimulatorWidget(BaseToolWidget):
    def __init__(self, settings, task_manager):
        super().__init__(settings, task_manager)

        self.attachments: List[Path] = []

        root = QVBoxLayout(self)

        # ---------- Identity / Envelope ----------
        id_group = QGroupBox("Envelope & Content")
        id_form = QFormLayout(id_group)
        self.from_name = QLineEdit("IT Support")
        self.from_addr = QLineEdit("it-support@example.com")
        self.to_addr = QLineEdit("employee@example.com")
        self.subject = QLineEdit("Action Required: Password Expiration Notice")
        self.brand = QComboBox()
        self.brand.addItems(["Generic", "Microsoft 365", "Google Workspace", "Okta", "GitHub"])
        self.tracker_pixel_cb = QCheckBox("Include tracker pixel (visual only)")
        self.tracker_pixel_cb.setChecked(False)

        id_form.addRow("From (Name):", self.from_name)
        id_form.addRow("From (Email):", self.from_addr)
        id_form.addRow("To (CSV):", self.to_addr)
        id_form.addRow("Subject:", self.subject)
        id_form.addRow("Theme:", self.brand)
        id_form.addRow(self.tracker_pixel_cb)

        # ---------- SMTP (Realistic, unused) ----------
        smtp_group = QGroupBox("SMTP Settings (visual only)")
        smtp_form = QFormLayout(smtp_group)
        self.smtp_host = QLineEdit("smtp.example.com")
        self.smtp_port = QSpinBox(); self.smtp_port.setRange(1, 65535); self.smtp_port.setValue(587)
        self.smtp_tls = QCheckBox("Use STARTTLS"); self.smtp_tls.setChecked(True)
        self.smtp_user = QLineEdit("phishbot@example.com")
        self.smtp_pass = QLineEdit(); self.smtp_pass.setEchoMode(QLineEdit.EchoMode.Password)

        smtp_form.addRow("Server:", self.smtp_host)
        smtp_form.addRow("Port:", self.smtp_port)
        smtp_form.addRow("", self.smtp_tls)
        smtp_form.addRow("Username:", self.smtp_user)
        smtp_form.addRow("Password:", self.smtp_pass)

        # ---------- Buttons ----------
        button_row = QHBoxLayout()
        self.btn_template = QPushButton("Generate Template")
        self.btn_preview = QPushButton("Preview")
        self.btn_export_eml = QPushButton("Export .eml")
        self.btn_export_html = QPushButton("Export .html")
        self.btn_add_attach = QPushButton("Add Attachment")
        self.btn_clear_attach = QPushButton("Clear Attachments")
        self.btn_send = QPushButton("Send")  # no-op by design

        button_row.addWidget(self.btn_template)
        button_row.addWidget(self.btn_preview)
        button_row.addWidget(self.btn_export_eml)
        button_row.addWidget(self.btn_export_html)
        button_row.addWidget(self.btn_add_attach)
        button_row.addWidget(self.btn_clear_attach)
        button_row.addWidget(self.btn_send)

        # ---------- Body / Preview ----------
        self.attach_label = QLabel("Attachments: none")
        self.html_view = QTextEdit()
        self.html_view.setAcceptRichText(True)
        self.html_view.setMinimumHeight(320)
        self.html_view.setPlaceholderText("Lure HTML will appear here. It also renders as a live preview.")

        # Layout
        root.addWidget(id_group)
        root.addWidget(smtp_group)
        root.addLayout(button_row)
        root.addWidget(self.attach_label)
        root.addWidget(QLabel("Lure Body (HTML):"))
        root.addWidget(self.html_view)

        # Wiring
        self.btn_template.clicked.connect(self._on_generate_template)
        self.btn_preview.clicked.connect(self._on_preview)
        self.btn_export_eml.clicked.connect(self._on_export_eml)
        self.btn_export_html.clicked.connect(self._on_export_html)
        self.btn_add_attach.clicked.connect(self._on_add_attachment)
        self.btn_clear_attach.clicked.connect(self._on_clear_attachments)

        # The whole point: make it look real, but do absolutely nothing on click.
        self.btn_send.clicked.connect(self._on_send_noop)

    # ---------- Actions ----------
    def _on_generate_template(self):
        brand = self.brand.currentText()
        html = self._build_html(brand)
        self.html_view.setPlainText(html)
        self._on_preview()

    def _on_preview(self):
        # Render HTML inside the QTextEdit for a live-ish preview (no external web engine needed).
        self.html_view.setHtml(self.html_view.toPlainText())

    def _on_export_html(self):
        html = self._get_html()
        if not html:
            self.show_error("Nothing to export. Generate or paste HTML first.")
            return
        fn, _ = QFileDialog.getSaveFileName(self, "Save HTML", "lure.html", "HTML Files (*.html)")
        if fn:
            Path(fn).write_text(html, encoding="utf-8")
            QMessageBox.information(self, "Saved", f"Saved HTML to:\n{fn}")

    def _on_export_eml(self):
        msg = self._build_message()
        fn, _ = QFileDialog.getSaveFileName(self, "Save EML", "lure.eml", "Email Files (*.eml)")
        if fn:
            Path(fn).write_bytes(msg.as_bytes())
            QMessageBox.information(self, "Saved", f"Saved EML to:\n{fn}")

    def _on_add_attachment(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Attachments", "", "All Files (*)")
        if files:
            for f in files:
                p = Path(f)
                if p.exists() and p.is_file():
                    self.attachments.append(p)
            self._refresh_attach_label()

    def _on_clear_attachments(self):
        self.attachments.clear()
        self._refresh_attach_label()

    def _refresh_attach_label(self):
        if not self.attachments:
            self.attach_label.setText("Attachments: none")
        else:
            names = ", ".join(p.name for p in self.attachments[:6])
            more = len(self.attachments) - 6
            if more > 0:
                names += f" (+{more} more)"
            self.attach_label.setText(f"Attachments: {names}")

    def _on_send_noop(self):
        # Intentionally NO-OP:
        # - No SMTP connections
        # - No local sinks
        # - No status messages
        # Clicking "Send" visually depresses the button and does nothing else.
        return

    # ---------- Helpers ----------
    def _get_html(self) -> str:
        return self.html_view.toPlainText().strip()

    def _build_message(self) -> EmailMessage:
        """Build a realistic multipart/alternative email with optional attachments."""
        html = self._get_html() or self._build_html(self.brand.currentText())

        # Optional tracker pixel (data URL only; no network)
        if self.tracker_pixel_cb.isChecked():
            pixel = (
                '<img src="data:image/gif;base64,'
                'R0lGODlhAQABAAAAACwAAAAAAQABAAA=" width="1" height="1" style="display:none;"/>'
            )
            # Insert before </body> if present, else append
            lower = html.lower()
            idx = lower.rfind("</body>")
            html = (html[:idx] + pixel + html[idx:]) if idx != -1 else (html + pixel)

        msg = EmailMessage()
        from_name = self.from_name.text().strip()
        from_addr = self.from_addr.text().strip()
        to_csv = self.to_addr.text().strip()
        subject = self.subject.text().strip()

        msg["From"] = f"{from_name} <{from_addr}>" if from_name else from_addr
        msg["To"] = to_csv
        msg["Subject"] = subject

        # Plain-text fallback
        msg.set_content("This message contains HTML content. If you see this, HTML was not displayed.")
        msg.add_alternative(html, subtype="html")

        # Attachments
        for p in self.attachments:
            ctype, enc = mimetypes.guess_type(str(p))
            if ctype is None:
                ctype = "application/octet-stream"
            maintype, subtype = ctype.split("/", 1)
            try:
                data = p.read_bytes()
                msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=p.name)
            except Exception:
                # Ignore unreadable files silently to keep the prop frictionless.
                pass

        return msg

    def _build_html(self, brand: str) -> str:
        palette = {
            "Generic": ("#222", "#0aa"),
            "Microsoft 365": ("#f3f2f1", "#2563eb"),
            "Google Workspace": ("#fff", "#1a73e8"),
            "Okta": ("#fff", "#0b5fff"),
            "GitHub": ("#0d1117", "#2f81f7"),
        }
        bg, accent = palette.get(brand, ("#222", "#0aa"))
        btn = "Review Now" if brand in ("Microsoft 365", "Google Workspace", "Okta") else "Open Document"
        title = self.subject.text().strip() or "Security Notice"
        return f"""<!doctype html>
<html>
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <title>{title}</title>
  </head>
  <body style="margin:0;padding:0;background:{bg};font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;color:#eaeaea;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
      <tr><td align="center" style="padding:24px 12px;">
        <table width="560" style="background:#111;border-radius:12px;overflow:hidden;">
          <tr>
            <td style="padding:20px 24px;background:{accent};color:white;font-weight:700;">
              {brand} Security Notice
            </td>
          </tr>
          <tr>
            <td style="padding:24px;color:#d7dde5;line-height:1.5;">
              <p>Hi,</p>
              <p>We detected an unusual sign-in to your account. To keep your access, please verify your session.</p>
              <p style="margin:24px 0;">
                <a href="#" style="background:{accent};color:white;text-decoration:none;padding:12px 18px;border-radius:8px;display:inline-block;">
                  {btn}
                </a>
              </p>
              <p style="font-size:12px;color:#8b95a1;">If you didn't request this, please ignore.</p>
            </td>
          </tr>
          <tr>
            <td style="padding:12px 24px;color:#8b95a1;font-size:12px;">Automated notification • {brand}</td>
          </tr>
        </table>
      </td></tr>
    </table>
  </body>
</html>
"""
