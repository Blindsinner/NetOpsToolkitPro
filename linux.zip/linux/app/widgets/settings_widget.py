# app/widgets/settings_widget.py
# -*- coding: utf-8 -*-
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout, 
    QLineEdit, QPushButton, QMessageBox
)
from PySide6.QtCore import Qt
# FIX: Import QIcon to handle icons and AppConfig for the asset path
from PySide6.QtGui import QIcon
from app.config import AppConfig

class SettingsWidget(QWidget):
    """
    A widget for configuring application-wide settings,
    such as API keys for various services.
    """
    def __init__(self, settings, task_manager, parent=None):
        super().__init__(parent)
        self.settings = settings

        main_layout = QVBoxLayout(self)
        main_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        # --- Security API Keys Group ---
        api_group = QGroupBox("API Keys for Security Tools")
        api_layout = QFormLayout(api_group)
        
        self.vulners_key_input = QLineEdit()
        self.hibp_key_input = QLineEdit()
        
        api_layout.addRow("Vulners API Key:", self.vulners_key_input)
        api_layout.addRow("HaveIBeenPwned API Key:", self.hibp_key_input)
        
        self.save_button = QPushButton("Save Settings")
        
        # FIX: Add the settings icon to the save button
        icon_path = AppConfig.ASSETS_DIR / "settings.svg"
        self.save_button.setIcon(QIcon(str(icon_path)))
        
        self.save_button.setFixedWidth(150)
        
        main_layout.addWidget(api_group)
        main_layout.addWidget(self.save_button, 0, Qt.AlignmentFlag.AlignLeft)

        # --- Load existing settings and connect signals ---
        self.load_settings()
        self.save_button.clicked.connect(self.save_settings)

    def load_settings(self):
        """Load API keys from QSettings and populate the input fields."""
        vulners_key = self.settings.value("security/vulners_api_key", "")
        hibp_key = self.settings.value("security/hibp_api_key", "")
        
        self.vulners_key_input.setText(vulners_key)
        self.hibp_key_input.setText(hibp_key)

    def save_settings(self):
        """Save the current values from the input fields to QSettings."""
        self.settings.setValue("security/vulners_api_key", self.vulners_key_input.text().strip())
        self.settings.setValue("security/hibp_api_key", self.hibp_key_input.text().strip())
        
        # Sync to ensure data is written to disk
        self.settings.sync()
        
        QMessageBox.information(self, "Settings Saved", "Your API keys and settings have been saved successfully.")
