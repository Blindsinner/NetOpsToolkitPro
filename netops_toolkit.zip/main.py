#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetOps Toolkit Pro: The All-in-One Command Platform

Author: MD FAYSAL MAHMUD
Version: 5.2.0
License: Apache 2.0
"""
from __future__ import print_function
import sys
import os
import subprocess
import venv
import logging
import platform
import shutil
from pathlib import Path

# --- Bootstrap Section ---
def bootstrap_and_launch():
    project_root = Path(__file__).resolve().parent
    venv_dir = project_root / ".venv-netops-toolkit"
    log_file = project_root / "netops_toolkit.log"

    # Configure logging
    log_format = "%(asctime)s [%(levelname)-7s] %(message)s"
    file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
    file_handler.setFormatter(logging.Formatter(log_format))
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(logging.Formatter(log_format))
    logging.basicConfig(level=logging.INFO, handlers=[file_handler, stream_handler])

    try:
        in_venv = Path(sys.prefix).resolve() == venv_dir.resolve()
    except Exception:
        in_venv = False

    if in_venv:
        return

    if sys.version_info < (3, 8):
        logging.error("Python 3.8 or newer is required to run this application.")
        sys.exit("Python 3.8 or newer is required to run this application.")

    first_run_marker = venv_dir / ".first_run_complete"
    if venv_dir.exists() and not first_run_marker.exists():
        logging.warning("Detected a stale or incomplete virtual environment. Cleaning up...")
        try:
            shutil.rmtree(venv_dir)
        except OSError as e:
            msg = f"Could not clean up the broken environment at '{venv_dir}'. Please remove it manually and try again. Error: {e}"
            logging.error(msg)
            sys.exit(msg)

    if not venv_dir.exists():
        logging.info(f"Creating virtual environment in '{venv_dir}'...")
        try:
            venv.create(str(venv_dir), with_pip=True)
        except Exception as e:
            msg = f"Failed to create virtual environment. Error: {e}"
            logging.error(msg)
            sys.exit(msg)

    py_exe = str(venv_dir / ('Scripts' if platform.system() == 'Windows' else 'bin') / 'python')
    
    def run_subprocess(command, error_msg, shell=False):
        logging.info(f"Running command: {' '.join(command)}")
        try:
            # Use shell=True for complex commands like those with sudo and &&
            result = subprocess.run(command, capture_output=True, text=True, check=True, encoding='utf-8', errors='replace', shell=shell)
            logging.info(f"Command successful. STDOUT:\n{result.stdout}")
            if result.stderr:
                logging.warning(f"Command has STDERR:\n{result.stderr}")
        except subprocess.CalledProcessError as e:
            logging.error(f"{error_msg}. Code: {e.returncode}\nSTDOUT:\n{e.stdout}\nSTDERR:\n{e.stderr}")
            print(f"\n--- [ERROR] --- \n{error_msg}. Check logs for details: {log_file}", file=sys.stderr)
            sys.exit(1)
        except FileNotFoundError:
            logging.error(f"Command not found: {command[0]}. Is Python/pip correctly installed and in the system PATH?")
            print(f"\n--- [ERROR] --- \nCommand '{command[0]}' not found. Ensure Python is in your PATH.", file=sys.stderr)
            sys.exit(1)

    # --- FIX: Install Linux-specific dependencies using apt-get ---
    if platform.system() == "Linux":
        logging.info("Detected Linux. Checking for external security tools...")
        # Check if sudo is available and if the user has sudo privileges
        if shutil.which("sudo") and os.geteuid() != 0:
            # Use a list for the command to avoid shell injection issues with sudo
            linux_deps_command = [
                "sudo", "bash", "-c",
                "apt-get update && apt-get install -y nikto hydra-gtk exploitdb"
            ]
            run_subprocess(linux_deps_command, "Failed to install Linux security tools.")
        elif os.geteuid() == 0: # Already running as root
             linux_deps_command = [
                "apt-get", "update", "&&", "apt-get", "install", "-y", "nikto", "hydra-gtk", "exploitdb"
             ]
             run_subprocess(linux_deps_command, "Failed to install Linux security tools as root.", shell=True)
        else:
            logging.warning("sudo command not found and not running as root. Please install 'nikto', 'hydra', and 'exploitdb' manually.")


    logging.info("Installing/upgrading Python dependencies...")
    
    run_subprocess([py_exe, "-m", "pip", "install", "--upgrade", "pip"], "Failed to upgrade pip.")

    dependencies = [
        "PySide6", "httpx[http2]", "dnspython", "cryptography", "rich",
        "qasync", "python-whois", "psutil", "pyserial", "scapy", "netmiko",
        "pysnmp", "pyyaml", "networkx", "mac-vendor-lookup", "asyncssh",
        "boto3", "openai", "google-generativeai", "ollama", "numpy",
        "vulners", "python-wappalyzer", "setuptools", "python-nmap"
    ]
    
    run_subprocess([py_exe, "-m", "pip", "install"] + dependencies, "Failed to install required Python dependencies.")
    
    first_run_marker.touch()

    logging.info("Bootstrap complete. Re-launching the application inside the virtual environment...")
    os.execv(py_exe, [py_exe, __file__] + sys.argv[1:])


def run_gui():
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    
    import qasync
    import asyncio
    from PySide6.QtWidgets import QApplication
    from app.main_window import MainWindow

    app = QApplication(sys.argv)
    loop = qasync.QEventLoop(app)
    asyncio.set_event_loop(loop)
    
    main_win = MainWindow()
    main_win.show()
    
    with loop:
        sys.exit(loop.run_forever())

def main():
    bootstrap_and_launch()
    run_gui()


if __name__ == "__main__":
    main()
