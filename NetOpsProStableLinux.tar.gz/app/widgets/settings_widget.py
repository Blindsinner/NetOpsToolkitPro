# app/widgets/settings_widget.py
# CORRECTED: Uses the theme-aware icon_manager instead of loading an icon directly.

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout, 
    QLineEdit, QPushButton, QMessageBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QColor
from app.config import AppConfig
from app.widgets.base_widget import BaseToolWidget
from app.assets.icon_manager import icon_manager

class SettingsWidget(BaseToolWidget):
    """
    A widget for configuring application-wide settings.
    """
    def __init__(self, settings, task_manager, parent=None):
        super().__init__(settings, task_manager, parent)

        main_layout = QVBoxLayout(self)
        main_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        api_group = QGroupBox("API Keys for Security Tools")
        api_layout = QFormLayout(api_group)
        
        self.vulners_key_input = QLineEdit()
        self.hibp_key_input = QLineEdit()
        
        api_layout.addRow("Vulners API Key:", self.vulners_key_input)
        api_layout.addRow("HaveIBeenPwned API Key:", self.hibp_key_input)
        
        self.save_button = QPushButton("Save Settings")
        
        # FIX: The icon is no longer loaded directly. It will be set by the MainWindow.
        self.save_button.setFixedWidth(150)
        
        main_layout.addWidget(api_group)
        main_layout.addWidget(self.save_button, 0, Qt.AlignmentFlag.AlignLeft)

        self.load_settings()
        self.save_button.clicked.connect(self.save_settings)

    def update_icons(self, color: QColor):
        """Public method called by MainWindow to update icons in this widget."""
        self.save_button.setIcon(icon_manager.get_icon("settings", color))

    def load_settings(self):
        """Load API keys from QSettings and populate the input fields."""
        vulners_key = self.settings.value("security/vulners_api_key", "")
        hibp_key = self.settings.value("security/hibp_api_key", "")
        
        self.vulners_key_input.setText(vulners_key)
        self.hibp_key_input.setText(hibp_key)

    def save_settings(self):
        """Save the current values from the input fields to QSettings."""
        self.settings.setValue("security/vulners_api_key", self.vulners_key_input.text().strip())
        self.settings.setValue("security/hibp_api_key", self.hibp_key_input.text().strip())
        
        self.settings.sync()
        
        self.show_info("Your API keys and settings have been saved successfully.")
