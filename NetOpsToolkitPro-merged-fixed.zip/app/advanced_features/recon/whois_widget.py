# app/advanced_features/recon/whois_widget.py
# Simple WHOIS widget that fits your existing BaseToolWidget + task_manager pattern.
# Uses the already-installed "python-whois" package (import name: whois).

import asyncio
from typing import Any, Dict

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QFormLayout,
    QLineEdit, QPushButton, QTextEdit, QLabel, QHBoxLayout
)

try:
    import whois as pywhois  # from python-whois
except Exception:  # pragma: no cover
    pywhois = None

from app.widgets.base_widget import BaseToolWidget


def _fmt_section(title: str, lines: list[str]) -> str:
    body = "\n".join(lines)
    return f"== {title} ==\n{body}" if lines else f"== {title} ==\n-"


def _fmt_value(v: Any) -> str:
    if v is None:
        return "-"
    if isinstance(v, (list, tuple, set)):
        return ", ".join([_fmt_value(x) for x in v if x is not None]) or "-"
    return str(v)


class WhoisWidget(BaseToolWidget):
    """
    Domain WHOIS lookup:
      • Uses python-whois (already in your deps list)
      • Runs lookups in a worker thread via task_manager (async-safe)
      • Prints key WHOIS fields in a readable format
    """

    def __init__(self, settings, task_manager):
        super().__init__(settings, task_manager)
        self._build_ui()

    # ---------------- UI ----------------
    def _build_ui(self):
        root = QVBoxLayout(self)

        # Input group
        box = QGroupBox("WHOIS Lookup")
        form = QFormLayout(box)

        self.domain_edit = QLineEdit()
        self.domain_edit.setPlaceholderText("example.com")
        self.btn_lookup = QPushButton("Lookup WHOIS")

        row = QHBoxLayout()
        row.addWidget(self.btn_lookup)

        form.addRow("Domain:", self.domain_edit)
        form.addRow(row)

        # Output
        self.out = QTextEdit()
        self.out.setReadOnly(True)

        note = QLabel("Note: WHOIS servers may throttle; results vary by TLD.")
        note.setWordWrap(True)

        root.addWidget(box)
        root.addWidget(self.out)
        root.addWidget(note)

        # Signals
        self.btn_lookup.clicked.connect(self._on_lookup)

    # ------------- Actions -------------
    def _on_lookup(self):
        domain = (self.domain_edit.text() or "").strip()
        if not domain:
            self.show_error("Enter a domain name (e.g., example.com).")
            return
        if pywhois is None:
            self.show_error("The 'python-whois' module is unavailable in this environment.")
            return

        async def task():
            try:
                # Run blocking WHOIS in a thread
                data: Dict[str, Any] = await asyncio.to_thread(pywhois.whois, domain)
                if not data:
                    self._append("No WHOIS data returned.")
                    return

                # Normalize keys (python-whois returns a dict-like object)
                def g(key: str):
                    try:
                        return data.get(key)
                    except Exception:
                        return getattr(data, key, None)

                basic = [
                    f"Domain: {_fmt_value(g('domain_name'))}",
                    f"Registrar: {_fmt_value(g('registrar'))}",
                    f"Status: {_fmt_value(g('status'))}",
                    f"Name Servers: {_fmt_value(g('name_servers'))}",
                ]
                contacts = [
                    f"Registrant: {_fmt_value(g('registrant_name'))}",
                    f"Registrant Email: {_fmt_value(g('emails'))}",
                    f"Org: {_fmt_value(g('org'))}",
                    f"Country: {_fmt_value(g('country'))}",
                ]
                dates = [
                    f"Creation Date: {_fmt_value(g('creation_date'))}",
                    f"Updated Date: {_fmt_value(g('updated_date'))}",
                    f"Expiration Date: {_fmt_value(g('expiration_date'))}",
                ]

                self.out.clear()
                self._append(_fmt_section("Basic", basic))
                self._append("")
                self._append(_fmt_section("Contacts", contacts))
                self._append("")
                self._append(_fmt_section("Dates", dates))
            except Exception as e:
                self._append(f"[ERROR] WHOIS lookup failed: {e}")

        self.task_manager.create_task(task())

    # ------------- Helpers -------------
    def _append(self, text: str):
        if text:
            self.out.append(text)

