#!/usr/bin/env python3
import os
import sys
import platform
import subprocess
import shlex
import logging
from pathlib import Path

# ---------- Logging ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)7s] %(message)s",
)
log = logging.getLogger(__name__)

# ---------- Config ----------
VENV_DIR = Path(".venv-netops-toolkit")
VENV_BIN = "Scripts" if platform.system().lower().startswith("win") else "bin"
VENV_PY = VENV_DIR / VENV_BIN / ("python.exe" if VENV_BIN == "Scripts" else "python")

# IMPORTANT: Only add dependencies. (Added: 'tldextract')
PY_REQS = [
    "PySide6",
    "httpx[http2]",
    "dnspython",
    "cryptography",
    "rich",
    "qasync",
    "python-whois",
    "psutil",
    "pyserial",
    "scapy",
    "netmiko",
    "pysnmp",
    "pyyaml",
    "networkx",
    "mac-vendor-lookup",
    "asyncssh",
    "boto3",
    "openai",
    "google-generativeai",
    "ollama",
    "numpy",
    "vulners",
    "python-wappalyzer",
    "setuptools",
    "python-nmap",
    "easysnmp",
    "natsort",
    "tldextract",  # <--- added to fix ModuleNotFoundError in asn_engine.py
]

LINUX_APT_PKGS = [
    "nikto",
    "hydra",
    "exploitdb",
    "nmap",
    "libsnmp-dev",
    "libpcap-dev",
]

def run_cmd(cmd: str, env=None) -> int:
    log.info("Running command: %s", cmd)
    try:
        proc = subprocess.run(
            cmd,
            shell=True,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
        )
        if proc.stdout:
            log.info("Command successful. STDOUT:\n%s", proc.stdout)
        return 0
    except subprocess.CalledProcessError as e:
        log.error("Command failed (%s). Output:\n%s", e.returncode, e.stdout)
        return e.returncode

def ensure_linux_tools():
    # Debian/Ubuntu/Kali
    log.info("Detected Linux. Checking for external security tools...")
    run_cmd("apt-get update && apt-get install -y " + " ".join(LINUX_APT_PKGS))

def ensure_macos_tools():
    # Keep lightweight; user asked to only add deps. No heavy changes.
    log.info("Detected macOS. (No external apt/brew installs performed automatically)")

def ensure_platform_tools():
    sysname = platform.system().lower()
    if "linux" in sysname:
        ensure_linux_tools()
    elif "darwin" in sysname:
        ensure_macos_tools()
    else:
        log.info("Detected %s. No external package steps configured.", platform.system())

def create_or_update_venv() -> None:
    if not VENV_PY.exists():
        log.info("Creating virtual environment in '%s'...", VENV_DIR)
        run_cmd(f"{shlex.quote(sys.executable)} -m venv {shlex.quote(str(VENV_DIR))}")
    else:
        log.info("Using existing virtual environment at '%s'.", VENV_DIR)

    # Upgrade pip
    log.info("Installing/upgrading Python dependencies...")
    run_cmd(f"{shlex.quote(str(VENV_PY))} -m pip install --upgrade pip")

    # Install our requirements
    cmd = f"{shlex.quote(str(VENV_PY))} -m pip install " + " ".join(PY_REQS)
    run_cmd(cmd)

def inside_venv() -> bool:
    return (
        hasattr(sys, "real_prefix")
        or (hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix)
        or os.environ.get("VIRTUAL_ENV") is not None
    )

def relaunch_inside_venv():
    log.info("Bootstrap complete. Re-launching the application inside the virtual environment...")
    os.execv(str(VENV_PY), [str(VENV_PY), str(Path(__file__).resolve())])

# ---------- GUI Launch ----------
def run_gui():
    # Import only after deps are present
    from PySide6.QtWidgets import QApplication
    from app.main_window import MainWindow

    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())

# ---------- Main ----------
def main():
    if not inside_venv():
        # Bootstrap phase
        if not VENV_DIR.exists():
            log.info("Creating virtual environment in '%s'...", VENV_DIR)
        create_or_update_venv()
        ensure_platform_tools()
        relaunch_inside_venv()
        return

    # Running inside venv: just start the app
    run_gui()

if __name__ == "__main__":
    main()
