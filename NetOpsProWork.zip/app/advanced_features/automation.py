# app/advanced_features/automation.py
# NOTE: This file is self-contained and ONLY affects the new Automation widget.
# It does not modify any of your existing modules.
#
# What changed vs earlier draft:
# - No asyncio tasks are created through TaskManager.
# - Work runs inside a QThread (AutomationWorker) with its own asyncio loop.
# - All UI updates happen via Qt signals (thread-safe).
# - We prompt for the master password *before* starting the worker (GUI thread).

import json
import yaml
import asyncio
from pathlib import Path
from typing import List, Dict, Any

from PySide6.QtCore import Qt, Signal, QObject, QThread
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QGroupBox, QListWidget,
    QPlainTextEdit, QPushButton, QFileDialog, QMessageBox
)

from app.config import AppConfig
from app.widgets.base_widget import BaseToolWidget
from app.core.device_connector import DeviceConnector
from app.core.credentials_manager import CredentialsManager

DEVICES_FILE = AppConfig.PROJECT_ROOT / "device_configs" / "devices.json"


# ------------ Worker (runs off the GUI thread) -----------------

class AutomationWorker(QThread):
    log = Signal(str)
    finished = Signal()

    def __init__(
        self,
        playbook_text: str,
        selected_hosts: List[str],
        devices: List[Dict[str, Any]],
        cred_manager: CredentialsManager
    ):
        super().__init__()
        self.playbook_text = playbook_text
        self.selected_hosts = selected_hosts
        self.devices = devices
        self.cred_manager = cred_manager
        self.connector = DeviceConnector()

    def _emit(self, msg: str):
        self.log.emit(msg)

    def run(self):
        # Run the async workflow inside this worker thread
        try:
            asyncio.run(self._run_async())
        except Exception as e:
            self._emit(f"ERROR: Unhandled exception in worker: {e}")
        finally:
            self.finished.emit()

    async def _run_async(self):
        # Parse playbook
        try:
            playbook = yaml.safe_load(self.playbook_text)
            if not isinstance(playbook, list):
                raise ValueError("Playbook must be a YAML list of plays.")
        except (yaml.YAMLError, ValueError) as e:
            self._emit(f"ERROR: Invalid playbook format. {e}")
            return

        # Stamp targets onto each play
        for play in playbook:
            play["hosts"] = list(self.selected_hosts)

        self._emit(f"--- Starting playbook execution on {', '.join(self.selected_hosts)} ---")

        for play in playbook:
            play_name = play.get("name", "Unnamed Play")
            self._emit(f"\n>> PLAY: {play_name}")

            for host in play.get("hosts", []):
                device_info = next((d for d in self.devices if d.get("host") == host), None)
                if not device_info:
                    self._emit(f"SKIPPING: Host {host} not found in device inventory.")
                    continue

                # Decrypt password (already validated before worker starts)
                decrypted = device_info.copy()
                try:
                    enc = device_info.get("password", "")
                    if enc:
                        decrypted["password"] = self.cred_manager.decrypt_password(enc)
                except Exception as e:
                    self._emit(f"ERROR: Could not decrypt password for {host}, skipping. Error: {e}")
                    continue

                self._emit(f"  >> HOST: {host}")

                for task in play.get("tasks", []):
                    task_name = task.get("name", "Unnamed Task")
                    self._emit(f"    >> TASK: {task_name}")

                    if "command" in task:
                        success, output = await self.connector.run_command(decrypted, task["command"])
                        self._emit(f"      STATUS: {'OK' if success else 'FAILED'}")
                        self._emit(f"      OUTPUT:\n{output}\n")

                    elif "config" in task:
                        commands = task["config"]
                        if isinstance(commands, str):
                            commands = [commands]
                        success, output = await self.connector.send_config(decrypted, commands)
                        self._emit(f"      STATUS: {'OK' if success else 'FAILED'}")
                        self._emit(f"      OUTPUT:\n{output}\n")

        self._emit("--- Playbook execution finished ---")


# ------------------ Thin logger (GUI thread) -------------------

class AutomationLogger(QObject):
    log_signal = Signal(str)

    def log(self, message: str):
        self.log_signal.emit(message)


# ----------------------- Main widget ---------------------------

class AutomationWidget(BaseToolWidget):
    def __init__(self, settings, task_manager):
        # NOTE: We keep your BaseToolWidget contract intact.
        super().__init__(settings, task_manager)

        self.devices = self._load_devices()
        self.logger = AutomationLogger()
        self.cred_manager = CredentialsManager()
        self._worker: AutomationWorker | None = None

        main_layout = QHBoxLayout(self)
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left pane: device list + actions
        left_pane = QWidget()
        left_layout = QVBoxLayout(left_pane)

        device_group = QGroupBox("Target Devices (from Config Manager)")
        device_layout = QVBoxLayout(device_group)
        self.device_list = QListWidget()
        self.device_list.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        for device in self.devices:
            label = device.get("host") or device.get("ip") or str(device)
            self.device_list.addItem(label)
        device_layout.addWidget(self.device_list)
        left_layout.addWidget(device_group)

        action_group = QGroupBox("Actions")
        action_layout = QVBoxLayout(action_group)
        self.load_playbook_btn = QPushButton("Load Playbook")
        self.save_playbook_btn = QPushButton("Save Playbook")
        self.run_playbook_btn = QPushButton("Run Playbook")
        self.run_playbook_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        action_layout.addWidget(self.load_playbook_btn)
        action_layout.addWidget(self.save_playbook_btn)
        action_layout.addWidget(self.run_playbook_btn)
        left_layout.addWidget(action_group)

        # Right pane: editor + log
        right_pane = QWidget()
        right_layout = QVBoxLayout(right_pane)

        editor_group = QGroupBox("Playbook Editor (YAML)")
        editor_layout = QVBoxLayout(editor_group)
        self.playbook_editor = QPlainTextEdit()
        self.playbook_editor.setFont(QFont("Consolas", 11))
        self.playbook_editor.setPlaceholderText("Enter or load a playbook...")
        self.playbook_editor.setPlainText(self.get_sample_playbook())
        editor_layout.addWidget(self.playbook_editor)
        right_layout.addWidget(editor_group, stretch=2)

        output_group = QGroupBox("Execution Log")
        output_layout = QVBoxLayout(output_group)
        self.output_log = QPlainTextEdit()
        self.output_log.setReadOnly(True)
        self.output_log.setFont(QFont("Consolas", 10))
        output_layout.addWidget(self.output_log)
        right_layout.addWidget(output_group, stretch=1)

        splitter.addWidget(left_pane)
        splitter.addWidget(right_pane)
        splitter.setSizes([300, 700])
        main_layout.addWidget(splitter)

        # Wire signals
        self.logger.log_signal.connect(self.append_log)
        self.load_playbook_btn.clicked.connect(self.load_playbook)
        self.save_playbook_btn.clicked.connect(self.save_playbook)
        self.run_playbook_btn.clicked.connect(self.run_playbook)

        if not self.devices:
            QMessageBox.information(
                self, "No Devices",
                "No devices found in inventory. Please add devices in 'Config Management' first."
            )
            self.device_list.setEnabled(False)
            self.run_playbook_btn.setEnabled(False)

    # -------- BaseToolWidget API --------
    def shutdown(self):
        # Stop worker if running
        if self._worker and self._worker.isRunning():
            self._worker.requestInterruption()
            self._worker.wait(1000)

    # -------------- Helpers -------------
    def _load_devices(self) -> List[Dict[str, Any]]:
        path: Path = DEVICES_FILE
        if not path.exists():
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception:
            return []

    def append_log(self, message: str):
        self.output_log.appendPlainText(message)
        sb = self.output_log.verticalScrollBar()
        sb.setValue(sb.maximum())

    def get_sample_playbook(self) -> str:
        return """- name: "Show version on selected devices"
  hosts: []
  tasks:
    - name: "Get IOS Version"
      command: "show version | include IOS"

- name: "Configure a test interface"
  hosts: []
  tasks:
    - name: "Configure Loopback99"
      config:
        - "interface Loopback99"
        - "description Automated by NetOpsToolkitPro"
"""

    # --------------- UI actions ----------------
    def load_playbook(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Playbook", "", "YAML Files (*.yml *.yaml)"
        )
        if path:
            with open(path, "r", encoding="utf-8") as f:
                self.playbook_editor.setPlainText(f.read())
            self.logger.log_signal.emit(f"INFO: Loaded playbook from {path}")

    def save_playbook(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Playbook", "", "YAML Files (*.yml *.yaml)"
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.playbook_editor.toPlainText())
            self.logger.log_signal.emit(f"INFO: Saved playbook to {path}")

    def run_playbook(self):
        playbook_text = self.playbook_editor.toPlainText()
        selected_hosts = [item.text() for item in self.device_list.selectedItems()]

        if not selected_hosts:
            QMessageBox.warning(self, "No Targets", "Please select at least one target device.")
            return

        # Confirm (GUI thread)
        reply = QMessageBox.question(
            self, "Confirm Execution",
            "You are about to run an automation playbook against:\n\n"
            f"{', '.join(selected_hosts)}\n\n"
            "This can make PERMANENT changes to device configurations.\n\n"
            "Are you sure you want to proceed?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.No:
            return

        # Prompt master password (GUI thread) BEFORE starting worker
        if not self.cred_manager.get_master_password(self):
            self.logger.log_signal.emit("ERROR: Master password not provided. Aborting playbook.")
            return

        # Start worker (no TaskManager; avoids cross-thread GUI access)
        self.output_log.clear()
        self.run_playbook_btn.setEnabled(False)

        self._worker = AutomationWorker(
            playbook_text=playbook_text,
            selected_hosts=selected_hosts,
            devices=self.devices,
            cred_manager=self.cred_manager,
        )
        self._worker.log.connect(self.append_log)          # thread-safe
        self._worker.finished.connect(self._on_worker_done)
        self._worker.start()

    def _on_worker_done(self):
        self.run_playbook_btn.setEnabled(True)
        self._worker = None

