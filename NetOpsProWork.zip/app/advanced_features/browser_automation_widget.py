# app/advanced_features/browser_automation_widget.py
# Embedded browser widget using PySide6 QtWebEngine (no PyQt5, no Playwright).
# Works on Kali/Ubuntu/macOS. If running as root on Linux, it disables the sandbox
# programmatically to avoid Chromium's no-sandbox crash.

from __future__ import annotations

import os
import sys
from typing import Optional

# If running as root on Linux, set flags before importing QtWebEngine.
try:
    if sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0:
        os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")
        os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--no-sandbox")
except Exception:
    # Don't hard-fail if environment detection does something odd
    pass

from PySide6.QtCore import Qt, QUrl, Signal, Slot
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QTextEdit,
    QLabel,
    QToolBar,
    QSizePolicy,
)

# QtWebEngine
from PySide6.QtWebEngineWidgets import QWebEngineView


class BrowserAutomationWidget(QWidget):
    """
    Minimal embedded browser for “browser automation” tasks using QWebEngineView.
    - No external Playwright/selenium dependencies
    - No PyQt5; uses PySide6 like the rest of the app
    - Safe to import on systems without accessibility bus
    """

    log_signal = Signal(str)

    def __init__(self, settings: Optional[object] = None, task_manager: Optional[object] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.settings = settings
        self.task_manager = task_manager

        self.setObjectName("BrowserAutomationWidget")
        self.setContentsMargins(0, 0, 0, 0)

        self._view = QWebEngineView(self)
        self._view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self._urlbar = QLineEdit(self)
        self._urlbar.setPlaceholderText("https://example.com")
        self._urlbar.returnPressed.connect(self._on_nav_enter)

        # Simple toolbar (Back/Forward/Reload/Home)
        self._toolbar = QToolBar(self)
        self._toolbar.setIconSize(self._toolbar.iconSize())  # default size

        act_back = QAction("Back", self)
        act_back.triggered.connect(self._view.back)
        self._toolbar.addAction(act_back)

        act_forward = QAction("Forward", self)
        act_forward.triggered.connect(self._view.forward)
        self._toolbar.addAction(act_forward)

        act_reload = QAction("Reload", self)
        act_reload.triggered.connect(self._view.reload)
        self._toolbar.addAction(act_reload)

        act_home = QAction("Home", self)
        act_home.triggered.connect(self._go_home)
        self._toolbar.addAction(act_home)

        # Go button
        self._go_btn = QPushButton("Go", self)
        self._go_btn.clicked.connect(self._on_go_clicked)

        # Log pane
        self._log = QTextEdit(self)
        self._log.setReadOnly(True)
        self._log.setMinimumHeight(100)
        self._log.setPlaceholderText("Navigation log…")

        # Wire signals from browser to log
        self._view.urlChanged.connect(self._on_url_changed)
        self._view.loadStarted.connect(lambda: self._append_log("Load started…"))
        self._view.loadProgress.connect(lambda p: self._append_log(f"Loading… {p}%"))
        self._view.loadFinished.connect(self._on_load_finished)

        # Layout
        top_bar = QHBoxLayout()
        top_bar.addWidget(QLabel("URL:", self))
        top_bar.addWidget(self._urlbar)
        top_bar.addWidget(self._go_btn)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        layout.addWidget(self._toolbar)
        layout.addLayout(top_bar)
        layout.addWidget(self._view, stretch=1)
        layout.addWidget(self._log, stretch=0)

        # Start page
        self._home_url = "https://example.com"
        self._urlbar.setText(self._home_url)
        self._view.setUrl(QUrl(self._home_url))

        # external log connection
        self.log_signal.connect(self._append_log)

    # ---------- helpers ----------

    def _go_home(self):
        self._view.setUrl(QUrl(self._home_url))

    def _sanitize_url(self, text: str) -> QUrl:
        text = (text or "").strip()
        if not text:
            return QUrl(self._home_url)
        # If it looks like a bare host, add scheme
        if "://" not in text:
            text = "https://" + text
        return QUrl(text)

    # ---------- slots ----------

    @Slot()
    def _on_nav_enter(self):
        self._on_go_clicked()

    @Slot()
    def _on_go_clicked(self):
        url = self._sanitize_url(self._urlbar.text())
        self._view.setUrl(url)

    @Slot(QUrl)
    def _on_url_changed(self, url: QUrl):
        self._urlbar.setText(url.toString())
        self._append_log(f"Navigated: {url.toString()}")

    @Slot(bool)
    def _on_load_finished(self, ok: bool):
        if ok:
            self._append_log("Load finished: OK")
            # Tiny JS to log title (kept simple; avoids automation deps)
            self._view.page().runJavaScript("document.title", self._on_got_title)
        else:
            self._append_log("Load finished: FAILED")

    def _on_got_title(self, title: str):
        if title:
            self._append_log(f"Title: {title}")

    def _append_log(self, text: str):
        self._log.append(text)

