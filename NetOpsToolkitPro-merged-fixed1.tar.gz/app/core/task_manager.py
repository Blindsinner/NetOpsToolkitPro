# -*- coding: utf-8 -*-
import asyncio
import logging
import threading
from concurrent.futures import Future
from typing import Coroutine, Set, Union, Callable, Optional

class TaskManager:
    """
    Central manager to run and track asyncio coroutines from Qt/GUI code.

    - Starts a dedicated background asyncio loop (daemon thread).
    - create_task(coro) schedules the coroutine safely even if no loop is
      running in the current thread.
    - cancel_all() cancels all outstanding tasks/futures.
    """

    def __init__(self) -> None:
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._ready = threading.Event()
        self.tasks: Set[Union[asyncio.Task, Future]] = set()
        self._start_background_loop()

    def _start_background_loop(self) -> None:
        def _runner() -> None:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self._loop = loop
            self._ready.set()
            try:
                loop.run_forever()
            finally:
                # Clean shutdown: cancel any pending tasks owned by this loop
                pending = asyncio.all_tasks(loop=loop)
                for t in pending:
                    t.cancel()
                if pending:
                    loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                loop.close()

        self._thread = threading.Thread(target=_runner, name="TaskManagerLoop", daemon=True)
        self._thread.start()
        self._ready.wait()

    def create_task(self, coro: Coroutine):
        """
        Schedule a coroutine onto the TaskManager's background loop.

        Returns a concurrent.futures.Future (thread-safe) which supports
        .add_done_callback(fn), .cancel(), .done(), .result(), etc.
        """
        if self._loop is None:
            raise RuntimeError("TaskManager event loop failed to start.")
        if not self._loop.is_running():
            # Extremely rare, but handle just in case
            self._start_background_loop()

        fut: Future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        # Track and auto-discard on completion
        def _discard(_):
            self.tasks.discard(fut)
        self.tasks.add(fut)
        fut.add_done_callback(_discard)
        return fut

    def cancel_all(self) -> None:
        logging.info(f"Cancelling {len(self.tasks)} outstanding tasks.")
        for f in list(self.tasks):
            try:
                f.cancel()
            except Exception:
                pass
        self.tasks.clear()

