# app/advanced_features/user_activity.py
# CORRECTED: The __init__ constructor has been updated to the standard signature.

import csv
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QHeaderView, QMessageBox, QFileDialog, QApplication
)
from PySide6.QtCore import Qt
from app.config import AppConfig
from app.widgets.base_widget import BaseToolWidget

class UserActivityWidget(BaseToolWidget):
    # FIX: The constructor now accepts settings and task_manager to match the standard.
    def __init__(self, settings, task_manager):
        super().__init__(settings, task_manager)

        main_layout = QVBoxLayout(self)

        self.activity_table = QTableWidget()
        self.activity_table.setColumnCount(3)
        self.activity_table.setHorizontalHeaderLabels(["Timestamp", "Action", "Details"])
        header = self.activity_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.activity_table.setAlternatingRowColors(True)
        self.activity_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

        button_layout = QHBoxLayout()
        refresh_btn = QPushButton("Refresh")
        export_btn = QPushButton("Export to CSV")
        clear_btn = QPushButton("Clear Log")
        
        button_layout.addWidget(refresh_btn)
        button_layout.addStretch()
        button_layout.addWidget(export_btn)
        button_layout.addWidget(clear_btn)

        main_layout.addWidget(self.activity_table)
        main_layout.addLayout(button_layout)

        refresh_btn.clicked.connect(self._load_logs)
        export_btn.clicked.connect(self._export_logs)
        clear_btn.clicked.connect(self._clear_logs)

        self._load_logs()

    def _load_logs(self):
        self.activity_table.setRowCount(0)
        if not AppConfig.ACTIVITY_LOG_FILE.exists():
            return
        
        try:
            with open(AppConfig.ACTIVITY_LOG_FILE, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in reversed(lines):
                    parts = line.strip().split(" - ", 2)
                    if len(parts) == 3:
                        row_pos = self.activity_table.rowCount()
                        self.activity_table.insertRow(row_pos)
                        self.activity_table.setItem(row_pos, 0, QTableWidgetItem(parts[0]))
                        self.activity_table.setItem(row_pos, 1, QTableWidgetItem(parts[1]))
                        self.activity_table.setItem(row_pos, 2, QTableWidgetItem(parts[2]))
        except Exception as e:
            self.show_error(f"Failed to read activity log: {e}")

    def _export_logs(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Log", "user_activity.csv", "CSV Files (*.csv)")
        if not path:
            return
        try:
            with open(path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                header = [self.activity_table.horizontalHeaderItem(i).text() for i in range(self.activity_table.columnCount())]
                writer.writerow(header)
                for row in range(self.activity_table.rowCount()):
                    row_data = [self.activity_table.item(row, col).text() for col in range(self.activity_table.columnCount())]
                    writer.writerow(row_data)
            self.show_info(f"Log exported to {path}")
        except Exception as e:
            self.show_error(f"Failed to export log: {e}")

    def _clear_logs(self):
        reply = QMessageBox.question(self, "Confirm Clear",
                                     "Are you sure you want to permanently delete the user activity log?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                     QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            try:
                if AppConfig.ACTIVITY_LOG_FILE.exists():
                    open(AppConfig.ACTIVITY_LOG_FILE, 'w').close()
                self._load_logs()
            except Exception as e:
                self.show_error(f"Could not clear log file: {e}")
