# app/advanced_features/recon/asn_widget.py
from PySide6.QtWidgets import QWidget, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QHBoxLayout, QFileDialog
from PySide6.QtCore import Qt
from app.widgets.base_widget import BaseToolWidget
from app.core.recon.asn_engine import ASNEngine
import csv, json

class ASNWidget(BaseToolWidget):
    def __init__(self, settings, task_manager):
        super().__init__(settings, task_manager)
        self.engine = ASNEngine(task_manager)
        self.engine.progress.connect(self._on_progress)
        self.engine.error.connect(self.show_error)
        self.engine.finished.connect(self._on_finished)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.input = QLineEdit(placeholderText="ASN (e.g., AS15169) or domain (example.com)")
        self.run_btn = QPushButton("Map Ranges")
        self.run_btn.clicked.connect(self._on_run)
        form.addRow("Target:", self.input)
        form.addRow(self.run_btn)
        layout.addLayout(form)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["ASN","Organization","Country","CIDR","Name","Description"])
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        btns = QHBoxLayout()
        self.export_csv = QPushButton("Export CSV")
        self.export_json = QPushButton("Export JSON")
        self.export_csv.clicked.connect(lambda: self._export('csv'))
        self.export_json.clicked.connect(lambda: self._export('json'))
        btns.addWidget(self.export_csv); btns.addWidget(self.export_json)
        layout.addLayout(btns)

        self.rows = []

    def _on_run(self):
        target = self.input.text().strip()
        if not target:
            self.show_error("Please enter an ASN or domain.")
            return
        self.table.setRowCount(0)
        self.rows = []
        self.engine.run(target)

    def _on_progress(self, msg: str):
        # Optional: could display status bar or log
        pass

    def _on_finished(self, rows):
        self.rows = rows
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.table.setItem(i, 0, QTableWidgetItem(str(r.get("asn",""))))
            self.table.setItem(i, 1, QTableWidgetItem(r.get("organization","") or ""))
            self.table.setItem(i, 2, QTableWidgetItem(r.get("country","") or ""))
            self.table.setItem(i, 3, QTableWidgetItem(r.get("cidr","") or ""))
            self.table.setItem(i, 4, QTableWidgetItem(r.get("name","") or ""))
            self.table.setItem(i, 5, QTableWidgetItem(r.get("description","") or ""))

    def _export(self, kind: str):
        if not self.rows:
            self.show_error("Nothing to export yet.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export", "", "CSV (*.csv);;JSON (*.json)")
        if not path:
            return
        if kind == 'csv' or path.endswith('.csv'):
            with open(path, 'w', newline='', encoding='utf-8') as f:
                w = csv.DictWriter(f, fieldnames=["asn","organization","country","cidr","name","description","source"])
                w.writeheader(); w.writerows(self.rows)
        else:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.rows, f, indent=2)

